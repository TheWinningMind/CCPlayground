DAVID SREERAMA — AP Biology Unit 2 Mind Maps

These mind maps have been renumbered to match the College Board AP Biology Course and Exam Description effective Fall 2025 (the current 2025–26 framework).

Current topic sequence:
2.1 Cell Structure and Function (represented by two complementary maps)
2.2 Cell Size
2.3 Plasma Membrane
2.4 Membrane Permeability
2.5 Membrane Transport
2.6 Facilitated Diffusion
2.7 Tonicity and Osmoregulation
2.8 Mechanisms of Transport
2.9 Cell Compartmentalization
2.10 Origins of Cell Compartmentalization

The two former maps for Topics 2.1 and 2.2 are both retained as complementary coverage of the revised Topic 2.1. The combined final image covers revised Topics 2.9 and 2.10.
